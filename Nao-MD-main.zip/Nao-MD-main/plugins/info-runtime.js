import fs from 'fs'
import fetch from 'node-fetch'
import moment from 'moment-timezone'
import axios from 'axios';
import sharp from 'sharp';

async function getBuffer(url) {
  const response = await axios({
    method: 'get',
    url,
    responseType: 'arraybuffer'
  });
  return Buffer.from(response.data, 'binary');
}

async function resizeImage(buffer, width, height) {
  return await sharp(buffer)
    .resize(width, height)
    .toBuffer();
}

let handler = async (m, { conn, args, command }) => {
	let _muptime
    if (process.send) {
      process.send('uptime')
      _muptime = await new Promise(resolve => {
        process.once('message', resolve)
        setTimeout(resolve, 1000)
      }) * 1000
    }
    let muptime = clockString(_muptime)
   let tag = `@${m.sender.replace(/@.+/, '')}`
  let mentionedJid = [m.sender]
  let thumbUrl = 'https://telegra.ph/file/e1d13e675c53103865cae.jpg';
  let thumb = await getBuffer(thumbUrl);
  let resizedThumb = await resizeImage(thumb, 300, 150);

  let memek = { 
    key: { remoteJid: 'status@broadcast', participant: '0@s.whatsapp.net' }, 
    message: { 
      orderMessage: { 
        itemCount: 9999, 
        status: 1, 
        thumbnail: resizedThumb, 
        surface: 1, 
        message: 'OSCAR OFFC', 
        orderTitle: wm, 
        sellerJid: '0@s.whatsapp.net' 
      } 
    }
  };


  await conn.sendMessage(m.chat, {
    text: `Aktif Selama ${muptime}`,
    contextInfo: {
      externalAdReply: {
        showAdAttribution: true,
        title: `RUNTIME BOT`,
        body: '2024 © Oscar Offc',
        thumbnailUrl: thumbUrl,
        sourceUrl: "https://whatsapp.com/channel/0029VaybYhxJuyAGHsDqiF1D",
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
  }, { quoted: memek });
}
handler.help = ['runtime'];
handler.tags = ['info'];
handler.command = /^(runtime|rt)$/i;

export default handler;

function ucapan() {
  const time = moment.tz('Asia/Jakarta').format('HH')
  let res = "Sudah Dini Hari Kok Belum Tidur Kak? 🥱"
  if (time >= 4) {
    res = "Pagi Kak 🌄"
  }
  if (time >= 10) {
    res = "Selamat Siang Kak ☀️"
  }
  if (time >= 15) {
    res = "Selamat Sore Kak 🌇"
  }
  if (time >= 18) {
    res = "Malam Kak 🌙"
  }
  return res
}
function clockString(ms) {
  let d = isNaN(ms) ? '--' : Math.floor(ms / 86400000)
  let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000) % 24
  let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60
  let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60
  return [d, ' *Days ☀️* \n', h, ' *Hours 🕐*\n', m, ' *Minute ⏰*\n', s, ' *Second ⏱️*'].map(v => v.toString().padStart(2, 0)).join('')
}